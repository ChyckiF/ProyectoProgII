// Cuando se hace clic en btnR, redirigir a la página de registro
const registerButton = document.getElementById('registerButton');
registerButton.addEventListener('click', () => {
    window.location.href = 'register.html';
});